'use strict';
const {S3Client,GetObjectCommand,PutObjectCommand}=require('@aws-sdk/client-s3');
const {makeHandler}=require('./core');
const client=new S3Client({region:'ru-central1',endpoint:'https://storage.yandexcloud.net',forcePathStyle:true,credentials:{accessKeyId:process.env.S3_KEY_ID||'',secretAccessKey:process.env.S3_SECRET_KEY||''}});
const bucket=process.env.S3_BUCKET||'';
const prefix=process.env.S3_PREFIX||'fso-rmrp';
const store={
 async get(kind){try{const result=await client.send(new GetObjectCommand({Bucket:bucket,Key:`${prefix}/${kind}.json`}));return JSON.parse(await result.Body.transformToString())}catch(e){if(e.name==='NoSuchKey'||e.name==='NotFound'||e.$metadata?.httpStatusCode===404)return null;throw e}},
 async put(kind,obj){await client.send(new PutObjectCommand({Bucket:bucket,Key:`${prefix}/${kind}.json`,Body:JSON.stringify(obj),ContentType:'application/json',CacheControl:'no-store'}))}
};
const handle=makeHandler(store);
exports.handler=async(event)=>{
 if(!bucket||!process.env.S3_KEY_ID||!process.env.S3_SECRET_KEY)return {statusCode:503,headers:{'Content-Type':'application/json'},body:JSON.stringify({ok:false,error:'Object Storage не настроен'})};
 return handle(event);
};

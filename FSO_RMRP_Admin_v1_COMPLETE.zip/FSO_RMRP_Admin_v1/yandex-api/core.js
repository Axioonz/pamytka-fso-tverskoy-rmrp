'use strict';
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const scrypt = promisify(crypto.scrypt);
const DEFAULT_SECTIONS = [
 {id:'situations',title:'Ситуации',description:'Служебные ситуации и действия сотрудника.',order:1,visible:true},
 {id:'reference',title:'Правовой справочник',description:'Правовые основания и пояснения.',order:2,visible:true},
 {id:'detention',title:'Порядок задержания',description:'Порядок и основания задержания.',order:3,visible:true},
 {id:'laws',title:'Законодательство',description:'Законы и кодексы проекта.',order:4,visible:true}
];
const MAX_ITEMS=1200, MAX_USERS=50;
function fail(status,message){const e=new Error(message);e.status=status;throw e}
function simpleString(v,max,mandatory=false){const s=typeof v==='string'?v.trim():'';if((mandatory&&!s)||s.length>max)fail(400,'Неверная длина поля');return s}
function json(status,data,origin){return {statusCode:status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Access-Control-Allow-Origin':origin||'null','Vary':'Origin','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Allow-Methods':'GET, POST, OPTIONS'},isBase64Encoded:false,body:JSON.stringify(data)}}
function equal(a,b){const x=Buffer.from(String(a)),y=Buffer.from(String(b));return x.length===y.length && crypto.timingSafeEqual(x,y)}
async function hashPassword(pass){const salt=crypto.randomBytes(24).toString('hex');const derived=await scrypt(pass,salt,64);return `scrypt:${salt}:${derived.toString('hex')}`}
async function verifyPassword(pass,hash){if(!hash || !hash.startsWith('scrypt:'))return false;const [,salt,hex]=hash.split(':');const v=await scrypt(pass,salt,64);return equal(v.toString('hex'),hex)}
function signToken(user,secret){const payload=Buffer.from(JSON.stringify({sub:user.username,rev:user.rev,exp:Math.floor(Date.now()/1000)+7200})).toString('base64url');const mac=crypto.createHmac('sha256',secret).update(payload).digest('base64url');return `${payload}.${mac}`}
function verifyToken(token,secret){try{const [payload,mac,...rest]=token.split('.');if(rest.length || !payload || !mac)return null;const correct=crypto.createHmac('sha256',secret).update(payload).digest('base64url');if(!equal(mac,correct))return null;const p=JSON.parse(Buffer.from(payload,'base64url').toString());if(!p.sub||!Number.isFinite(p.exp)||p.exp<=Date.now()/1000)return null;return p}catch{return null}}
function credentials(user){return {username:user.username,role:user.role,disabled:!!user.disabled}}
function contentBase(){return {sections:DEFAULT_SECTIONS.map(s=>({...s})),items:[],revision:0}}
function originAllowed(reqOrigin,allowed){return !reqOrigin || allowed.includes(reqOrigin)}
function makeHandler(storage,env=process.env){
 const secret=env.SESSION_SECRET||'';
 const allowed=(env.ALLOWED_ORIGINS||'').split(',').map(s=>s.trim()).filter(Boolean);
 async function getContent(){return await storage.get('content')||contentBase()}
 async function getUsers(){let db=await storage.get('users');if(db)return db;
   const user=simpleString(env.BOOTSTRAP_ADMIN_LOGIN||'',32,true).toLowerCase(),pass=env.BOOTSTRAP_ADMIN_PASSWORD||'';
   if(!/^[a-z0-9_.-]{3,32}$/.test(user)||pass.length<16)fail(503,'Сначала настройте владельца в Yandex Cloud');
   db={users:[{username:user,passwordHash:await hashPassword(pass),role:'owner',disabled:false,rev:1,failures:0,lockUntil:0}]};
   await storage.put('users',db);return db;
 }
 async function handler(event){
  const headers=Object.fromEntries(Object.entries(event.headers||{}).map(([k,v])=>[k.toLowerCase(),v]));
  const reqOrigin=headers.origin||'',method=(event.httpMethod||'GET').toUpperCase(),action=event.queryStringParameters?.action||'public';
  const safeOrigin=allowed.includes(reqOrigin)?reqOrigin:'';
  if(!allowed.length || secret.length<32)return json(503,{ok:false,error:'Сервер ещё не настроен'},safeOrigin);
  if(!originAllowed(reqOrigin,allowed))return json(403,{ok:false,error:'Недопустимый источник запроса'},'');
  if(method==='OPTIONS')return json(204,{},safeOrigin);
  try{
   if(action==='health'&&method==='GET')return json(200,{ok:true,service:'FSO RMRP Admin API'},safeOrigin);
   if(action==='public'&&method==='GET'){
    const content=await getContent(),sections=content.sections.filter(s=>s.visible).sort((a,b)=>a.order-b.order);
    const ids=new Set(sections.map(s=>s.id));
    return json(200,{ok:true,sections,items:content.items.filter(i=>i.status==='published'&&ids.has(i.sectionId)).map(({id,title,summary,body,sectionId,sourceUrl,updatedAt})=>({id,title,summary,body,sectionId,sourceUrl,updatedAt}))},safeOrigin);
   }
   if(method!=='POST' || !['login','logout','admin-data','save-item','delete-item','save-section','delete-section','create-user','update-user'].includes(action))fail(404,'Запрос не найден');
   const raw=event.isBase64Encoded?Buffer.from(event.body||'','base64').toString('utf8'):(event.body||'');
   if(Buffer.byteLength(raw)>150000)fail(413,'Слишком большой запрос');
   let data;try{data=raw?JSON.parse(raw):{}}catch{fail(400,'Некорректный JSON')}
   if(typeof data!=='object'||!data||Array.isArray(data))fail(400,'Неверный формат данных');
   const db=await getUsers();
   if(action==='login'){
    const username=simpleString(data.username,32,true).toLowerCase(),pass=typeof data.password==='string'?data.password:'';
    const u=db.users.find(x=>x.username===username),now=Date.now();
    if(!u || u.disabled){if(u)await verifyPassword(pass,u.passwordHash);else await scrypt(pass||'?',crypto.randomBytes(16),64);fail(401,'Неверный логин или пароль')}
    if(u.lockUntil>now)fail(429,'Слишком много попыток. Повторите через 15 минут');
    if(!(await verifyPassword(pass,u.passwordHash))){u.failures=(u.failures||0)+1;if(u.failures>=5){u.failures=0;u.lockUntil=now+15*60*1000}await storage.put('users',db);fail(401,'Неверный логин или пароль')}
    u.failures=0;u.lockUntil=0;await storage.put('users',db);
    return json(200,{ok:true,token:signToken(u,secret),expiresIn:7200,user:credentials(u)},safeOrigin);
   }
   const bearer=/^Bearer (.+)$/i.exec(headers.authorization||'');const token=bearer&&verifyToken(bearer[1],secret);
   const u=token&&db.users.find(x=>x.username===token.sub&&!x.disabled&&x.rev===token.rev);
   if(!u)fail(401,'Требуется вход в админ-панель');
   if(action==='logout'){u.rev++;await storage.put('users',db);return json(200,{ok:true},safeOrigin)}
   if(action==='admin-data'){
    const content=await getContent();return json(200,{ok:true,user:credentials(u),sections:content.sections,items:content.items,users:u.role==='owner'?db.users.map(credentials):undefined},safeOrigin);
   }
   if(action==='create-user'||action==='update-user'){
    if(u.role!=='owner')fail(403,'Только владелец управляет пользователями');
    const username=simpleString(data.username,32,true).toLowerCase();
    if(!/^[a-z0-9_.-]{3,32}$/.test(username))fail(400,'Логин: 3–32 символа, латиница, цифры и ._-');
    const pass=typeof data.password==='string'?data.password:'';
    if(action==='create-user'){
     if(db.users.length>=MAX_USERS)fail(400,'Достигнут лимит пользователей');
     if(db.users.some(x=>x.username===username))fail(409,'Логин уже занят');
     if(pass.length<12||pass.length>128)fail(400,'Пароль: от 12 до 128 символов');
     const role=data.role==='owner'?'owner':'editor';
     db.users.push({username,passwordHash:await hashPassword(pass),role,disabled:false,rev:1,failures:0,lockUntil:0});
    }else{
     const target=db.users.find(x=>x.username===username);if(!target)fail(404,'Пользователь не найден');
     if(target.username===u.username && (data.disabled||data.role&&data.role!=='owner'))fail(400,'Нельзя отключить себя или снять права владельца');
     if(data.role!==undefined){if(!['owner','editor'].includes(data.role))fail(400,'Неверная роль');target.role=data.role}
     if(typeof data.disabled==='boolean')target.disabled=data.disabled;
     if(pass){if(pass.length<12||pass.length>128)fail(400,'Пароль: от 12 до 128 символов');target.passwordHash=await hashPassword(pass)}
     target.failures=0;target.lockUntil=0;target.rev++;
     if(db.users.filter(x=>x.role==='owner'&&!x.disabled).length===0)fail(400,'Должен остаться хотя бы один владелец');
    }
    await storage.put('users',db);return json(200,{ok:true,users:db.users.map(credentials)},safeOrigin);
   }
   const content=await getContent();
   if(action==='save-item'){
    const incoming=data.item||{},id=incoming.id?simpleString(incoming.id,80,true):crypto.randomUUID();
    const existing=content.items.find(i=>i.id===id);
    if(!existing && content.items.length>=MAX_ITEMS)fail(400,'Достигнут лимит материалов');
    if(u.role==='editor' && (existing?.status==='published'||incoming.status==='published'))fail(403,'Редактор работает только с черновиками');
    const title=simpleString(incoming.title,180,true),summary=simpleString(incoming.summary,800),body=simpleString(incoming.body,50000,true);
    const sectionId=simpleString(incoming.sectionId,80,true);
    if(!content.sections.some(s=>s.id===sectionId))fail(400,'Неизвестный раздел');
    const status=incoming.status==='published'?'published':'draft';
    const sourceUrl=simpleString(incoming.sourceUrl,1000);
    if(sourceUrl&&!/^https:\/\/\S+$/i.test(sourceUrl))fail(400,'Укажите ссылку с https://');
    const updatedAt=new Date().toISOString();
    const record={id,title,summary,body,sectionId,status,sourceUrl,updatedAt,updatedBy:u.username};
    if(existing){const k=content.items.indexOf(existing);content.items[k]=record}else content.items.push(record);
    content.revision++;await storage.put('content',content);return json(200,{ok:true,item:record},safeOrigin);
   }
   if(action==='delete-item'){
    const id=simpleString(data.id,80,true),it=content.items.find(i=>i.id===id);
    if(!it)fail(404,'Материал не найден');
    if(u.role==='editor'&&it.status==='published')fail(403,'Редактор не может удалять опубликованное');
    content.items=content.items.filter(i=>i.id!==id);content.revision++;await storage.put('content',content);
    return json(200,{ok:true},safeOrigin);
   }
   if(action==='save-section'){
    if(u.role!=='owner')fail(403,'Только владелец меняет разделы');
    const incoming=data.section||{},id=incoming.id?simpleString(incoming.id,80,true):`section-${crypto.randomUUID()}`;
    const title=simpleString(incoming.title,100,true),description=simpleString(incoming.description,300);
    if(content.sections.length>=40&&!content.sections.some(s=>s.id===id))fail(400,'Достигнут лимит разделов');
    const section={id,title,description,visible:incoming.visible!==false,order:Number.isFinite(incoming.order)?Math.max(0,Math.min(1000,incoming.order)):content.sections.length+1};
    const k=content.sections.findIndex(s=>s.id===id);
    if(k<0)content.sections.push(section);else content.sections[k]=section;
    content.revision++;await storage.put('content',content);return json(200,{ok:true,section},safeOrigin);
   }
   if(action==='delete-section'){
    if(u.role!=='owner')fail(403,'Только владелец меняет разделы');
    const id=simpleString(data.id,80,true);
    if(DEFAULT_SECTIONS.some(s=>s.id===id))fail(400,'Базовые разделы можно переименовать или скрыть, но не удалить');
    if(content.items.some(i=>i.sectionId===id))fail(409,'В разделе есть материалы. Сначала перенесите или удалите их');
    content.sections=content.sections.filter(s=>s.id!==id);content.revision++;await storage.put('content',content);return json(200,{ok:true},safeOrigin);
   }
   fail(404,'Запрос не найден');
  }catch(e){if(!e.status)console.error('FSO API error',e.name,e.message);return json(e.status||500,{ok:false,error:e.status?e.message:'Внутренняя ошибка сервера'},safeOrigin)}
 }
 return handler;
}
module.exports={makeHandler,hashPassword,verifyPassword,DEFAULT_SECTIONS};

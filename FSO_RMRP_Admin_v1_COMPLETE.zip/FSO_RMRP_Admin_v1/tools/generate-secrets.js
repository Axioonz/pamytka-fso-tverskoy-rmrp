// Запускайте ЛОКАЛЬНО: node tools/generate-secrets.js
// Сгенерированные значения не сохраняются в файлы.
const { randomBytes } = require('node:crypto');
const chars='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%';
function password(size){const raw=randomBytes(size);return [...raw].map(b=>chars[b%chars.length]).join('')}
console.log('\nБОТСТРАП ВЛАДЕЛЬЦА (не публикуйте в GitHub!)');
console.log('BOOTSTRAP_ADMIN_LOGIN = owner');
console.log('BOOTSTRAP_ADMIN_PASSWORD = '+password(24));
console.log('SESSION_SECRET = '+randomBytes(48).toString('hex'));
console.log('\nСохраните пароль владельца в менеджере паролей.');
